/*                     __                                               *\
**     ________ ___   / /  ___     Scala API                            **
**    / __/ __// _ | / /  / _ |    (c) 2002-2013, LAMP/EPFL             **
**  __\ \/ /__/ __ |/ /__/ __ |    http://scala-lang.org/               **
** /____/\___/_/ |_/____/_/ | |                                         **
**                          |/                                          **
\*                                                                      */

package scala.annotation

/** If this annotation is present on a method, it will be treated as a bridge method.
 */
@deprecated("Reconsider whether using this annotation will accomplish anything", "2.10.0")
private[scala] class bridge extends scala.annotation.StaticAnnotation
