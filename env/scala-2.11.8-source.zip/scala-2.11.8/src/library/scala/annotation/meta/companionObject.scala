/*                     __                                               *\
**     ________ ___   / /  ___     Scala API                            **
**    / __/ __// _ | / /  / _ |    (c) 2002-2013, LAMP/EPFL             **
**  __\ \/ /__/ __ |/ /__/ __ |    http://scala-lang.org/               **
** /____/\___/_/ |_/____/_/ | |                                         **
**                          |/                                          **
\*                                                                      */
package scala.annotation.meta

/**
 * Currently unused; intended as an annotation target for classes such as case classes
 * that automatically generate a companion object
 */
final class companionObject extends scala.annotation.StaticAnnotation
