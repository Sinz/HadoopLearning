/*                     __                                               *\
**     ________ ___   / /  ___     Scala API                            **
**    / __/ __// _ | / /  / _ |    (c) 2002-2013, LAMP/EPFL             **
**  __\ \/ /__/ __ |/ /__/ __ |    http://scala-lang.org/               **
** /____/\___/_/ |_/____/_/ | |                                         **
**                          |/                                          **
\*                                                                      */
package scala.annotation.meta

/**
 * An annotation giving particulars for a language feature in object `scala.language`.
 */
final class languageFeature(feature: String, enableRequired: Boolean) extends scala.annotation.StaticAnnotation
