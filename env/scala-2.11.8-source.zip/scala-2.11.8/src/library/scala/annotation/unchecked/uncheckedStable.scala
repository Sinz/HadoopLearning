/*                     __                                               *\
**     ________ ___   / /  ___     Scala API                            **
**    / __/ __// _ | / /  / _ |    (c) 2002-2013, LAMP/EPFL             **
**  __\ \/ /__/ __ |/ /__/ __ |    http://scala-lang.org/               **
** /____/\___/_/ |_/____/_/ | |                                         **
**                          |/                                          **
\*                                                                      */
package scala.annotation.unchecked

/** An annotation for values that are assumed to be stable even though their
 *  types are volatile.
 *
 *  @since 2.7
 */
final class uncheckedStable extends scala.annotation.StaticAnnotation {}
