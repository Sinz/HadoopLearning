/*                     __                                               *\
**     ________ ___   / /  ___     Scala API                            **
**    / __/ __// _ | / /  / _ |    (c) 2002-2013, LAMP/EPFL             **
**  __\ \/ /__/ __ |/ /__/ __ |    http://scala-lang.org/               **
** /____/\___/_/ |_/____/_/ | |                                         **
**                          |/                                          **
\*                                                                      */

package scala.annotation

/** A method annotation which suppresses the creation of
 *  additional specialized forms based on enclosing specialized
 *  type parameters.
 *
 *  @since 2.10
 */
class unspecialized extends scala.annotation.StaticAnnotation
